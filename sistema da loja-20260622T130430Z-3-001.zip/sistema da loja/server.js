const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const path = require('path');
const mysqldump = require('mysqldump');
const fs = require('fs'); // Faltava a importação no topo

const app = express();

app.use(cors());
app.use(express.json());

// ==========================================
// CONFIGURAÇÃO DO BANCO DE DADOS
// ==========================================
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'insanus_pdv'
});

db.connect(err => {
    if (err) console.error('Erro ao conectar ao MySQL:', err);
    else console.log('Conectado ao MySQL com sucesso!');
});

// ==========================================
// ROTAS DE SISTEMA (BACKUP E RELATÓRIO)
// ==========================================
app.get('/backup-drive', async (req, res) => {
    try {
        const dataHoje = new Date().toISOString().split('T')[0];
        const nomeArquivo = `backup_insanus_${dataHoje}.sql`;
        const caminhoDestino = path.join('G:', 'Meu Drive', 'Backups_Sistema', nomeArquivo);

        await mysqldump({
            connection: { host: 'localhost', user: 'root', password: '', database: 'insanus_pdv' },
            dumpToFile: caminhoDestino,
        });
        res.send({ mensagem: "Backup salvo no Drive!", arquivo: nomeArquivo });
    } catch (error) {
        res.status(500).send("Erro: " + error.message);
    }
});

app.post('/salvar-relatorio', (req, res) => {
    const { conteudo } = req.body;
    const pastaDestino = 'C:\\Users\\Pichau\\Desktop\\relatorio de vendas';

    if (!fs.existsSync(pastaDestino)) fs.mkdirSync(pastaDestino);

    const nomeArquivo = `relatorio_${Date.now()}.txt`;
    const caminhoCompleto = path.join(pastaDestino, nomeArquivo);

    fs.writeFile(caminhoCompleto, conteudo, (err) => {
        if (err) return res.status(500).send('Erro ao salvar arquivo: ' + err);
        res.send('Relatório salvo com sucesso em: ' + caminhoCompleto);
    });
});

// ==========================================
// ROTAS DE FIADOS
// ==========================================
app.get('/fiados', (req, res) => {
    const sql = "SELECT *, DATE_FORMAT(data_divida, '%d/%m/%Y') as data_pt FROM fiados WHERE total > pago";
    db.query(sql, (err, result) => {
        if (err) return res.status(500).send(err);
        res.send(result);
    });
});

app.get('/fiados/:id/historico', (req, res) => {
    const { id } = req.params;
    const sql = "SELECT id, valor_pago, metodo, DATE_FORMAT(data_pagamento, '%d/%m/%Y %H:%i') as data_pt FROM historico_pagamentos_fiado WHERE fiado_id = ? ORDER BY data_pagamento DESC";
    db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send(result);
    });
});

app.post('/fiados', (req, res) => {
    const { cliente, servico, total, pago } = req.body;
    const sql = 'INSERT INTO fiados (cliente, servico, total, pago, data_divida) VALUES (?, ?, ?, ?, NOW())';
    db.query(sql, [cliente, servico, total, pago], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Fiado registrado com sucesso!');
    });
});

app.put('/fiados/:id', (req, res) => {
    const { id } = req.params;
    const { valorPago, metodo } = req.body; // Agora recebemos também o método de pagamento do Front
    
    const sqlUpdate = 'UPDATE fiados SET pago = pago + ? WHERE id = ?';
    db.query(sqlUpdate, [valorPago, id], (err, result) => {
        if (err) return res.status(500).send(err);
        
        // Após atualizar o saldo, insere o registro na tabela de histórico
        const sqlHistorico = 'INSERT INTO historico_pagamentos_fiado (fiado_id, valor_pago, metodo, data_pagamento) VALUES (?, ?, ?, NOW())';
        db.query(sqlHistorico, [id, valorPago, metodo || 'Não Informado'], (errHist) => {
            if (errHist) {
                console.error('Erro ao salvar histórico do fiado:', errHist);
                // Mesmo que dê erro no histórico, o saldo principal foi atualizado com sucesso
            }
            res.send('Pagamento registrado e saldo atualizado!');
        });
    });
});

app.put('/fiados/adicionar/:id', (req, res) => {
    const { id } = req.params;
    const { novo_item, valor_adicional } = req.body;
    const sql = "UPDATE fiados SET total = total + ?, servico = CONCAT(servico, ' + ', ?) WHERE id = ?";
    db.query(sql, [valor_adicional, novo_item, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send("Item adicionado à conta com sucesso!");
    });
});

// ==========================================
// ROTAS DE PRODUTOS E ESTOQUE
// ==========================================
app.get('/produtos', (req, res) => {
    const searchTerm = req.query.search || '';
    const orderBy = req.query.order || 'nome';
    let sql = "SELECT * FROM produtos WHERE nome LIKE ?";

    if (orderBy === 'nome') sql += " ORDER BY nome ASC";
    else if (orderBy === 'estoque') sql += " ORDER BY (estoque + 0) ASC";
    else if (orderBy === 'preco') sql += " ORDER BY preco ASC";

    db.query(sql, [`%${searchTerm}%`], (err, result) => {
        if (err) return res.status(500).send("Erro no servidor");
        res.send(result);
    });
});

app.post('/produtos', (req, res) => {
    const { nome, preco, estoque } = req.body;
    const sql = `
        INSERT INTO produtos (nome, preco, estoque) 
        VALUES (?, ?, ?) 
        ON DUPLICATE KEY UPDATE 
        estoque = estoque + VALUES(estoque), 
        preco = VALUES(preco)`;
    db.query(sql, [nome, preco, estoque], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Estoque atualizado com sucesso!');
    });
});

app.put('/produtos/:id', (req, res) => {
    const { id } = req.params;
    const { nome, preco, estoque } = req.body;
    const sql = 'UPDATE produtos SET nome = ?, preco = ?, estoque = ? WHERE id = ?';
    db.query(sql, [nome, preco, estoque, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Produto atualizado com sucesso!');
    });
});

app.put('/produtos/:id/baixa', (req, res) => {
    const { id } = req.params;
    const { quantidade } = req.body;
    const sql = 'UPDATE produtos SET estoque = estoque - ? WHERE id = ?';
    db.query(sql, [quantidade, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Baixa no estoque realizada com sucesso!');
    });
});

app.delete('/produtos/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM produtos WHERE id = ?', [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Produto excluído!');
    });
});

// ==========================================
// ROTAS DE VENDAS
// ==========================================
app.get('/vendas', (req, res) => {
    const { inicio, fim } = req.query;
    let sql = 'SELECT * FROM vendas';
    let parametros = [];

    // 1º O WHERE (Se houver filtro de data)
    if (inicio && fim) {
        sql += ' WHERE data_venda BETWEEN ? AND ?';
        parametros = [`${inicio} 00:00:00`, `${fim} 23:59:59`];
    }

    // 2º O ORDER BY e o LIMIT no final
    sql += ' ORDER BY id DESC LIMIT 100';

    db.query(sql, parametros, (err, results) => {
        if (err) {
            console.error("Erro ao buscar vendas:", err);
            return res.status(500).send(err);
        }
        res.json(results);
    });
});

app.post('/vendas', (req, res) => {
    const { produtos, pagamento, total } = req.body;
    // Adicionado "data_venda" e "NOW()" para gravar o horário exato da venda
    const sql = 'INSERT INTO vendas (produtos, pagamento, total, data_venda) VALUES (?, ?, ?, NOW())';
    db.query(sql, [produtos, pagamento, total], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Venda registrada!');
    });
});

app.put('/vendas/:id', (req, res) => {
    const { id } = req.params;
    const { produtos, pagamento, total } = req.body;
    const sql = 'UPDATE vendas SET produtos = ?, pagamento = ?, total = ? WHERE id = ?';
    db.query(sql, [produtos, pagamento, total, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Venda atualizada com sucesso!');
    });
});

app.delete('/vendas/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM vendas WHERE id = ?';
    db.query(sql, [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Venda excluída!');
    });
});

app.delete('/vendas', (req, res) => {
    const sql = 'DELETE FROM vendas';
    db.query(sql, (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Histórico de vendas limpo com sucesso!');
    });
});

// ==========================================
// INICIAR SERVIDOR
// ==========================================
app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});