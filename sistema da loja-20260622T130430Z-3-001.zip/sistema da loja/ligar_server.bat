@echo off
title Servidor PDV - Insanus CellSystem
echo Iniciando o Servidor Node.js...

:: 1. CRIA O BACKUP AUTOMATICO ANTES DE LIGAR
echo Fazendo backup de seguranca do banco de dados...
set DATA_HOJE=%date:/=-%
:: Altere o caminho abaixo se o seu XAMPP estiver em outro lugar
"C:\xampp\mysql\bin\mysqldump.exe" -u root insanus_pdv > "C:\Relatorios_Vendas\backup_insanus_%DATA_HOJE%.sql"

:: 2. LIGA O SERVIDOR
start /b node server.js

echo Aguardando o servidor estabilizar...
timeout /t 3 /nobreak > nul

echo Abrindo o Sistema no Chrome...
start chrome "%cd%\index.html"

echo.
echo ===========================================
echo    SISTEMA RODANDO - BACKUP REALIZADO
echo ===========================================
echo.